<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo $page_title; ?></title>
	<link rel="stylesheet" href="<?php echo base_url('public/css/bootstrap4.0.0.min.css'); ?> ">
</head>
<body>
	<div id="wrapper">
		<header class="bg-info text-white text-center">
			<div class="container-fluid">
				<div class="row">
					<div class="col-12">
						<h1>Codeigniter 4 : CRUD</h1>
					</div>
				</div>
			</div>
		</header>
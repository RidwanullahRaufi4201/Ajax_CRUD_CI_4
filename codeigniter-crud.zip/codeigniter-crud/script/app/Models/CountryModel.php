<?php

namespace App\Models;
use CodeIgniter\Database\ConnectionInterface;
use CodeIgniter\Model;
 
class CountryModel extends Model
{
    protected $table = 'country';
 
}


?>
<?php

namespace App\Models;

use CodeIgniter\Model;

class Classes extends Model
{
	
	protected $table = 'classes';
	
}
